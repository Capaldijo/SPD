<?php

namespace Descartes\EvenementBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DescartesEvenementBundle extends Bundle
{
}
