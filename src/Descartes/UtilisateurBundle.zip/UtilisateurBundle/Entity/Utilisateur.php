<?php

namespace Descartes\UtilisateurBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\Security\Core\User\UserInterface;

/**
 * Utilisateur
 *
 * @ORM\Table()
 * @ORM\Entity(repositoryClass="Descartes\UtilisateurBundle\Entity\UtilisateurRepository")
 */
class utilisateur implements UserInterface, \Serializable
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id_utilisateur", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="nom", type="text")
     * @Assert\NotBlank()
     */
    private $nom;

    /**
     * @var string
     *
     * @ORM\Column(name="prenom", type="text")
     * @Assert\NotBlank()
     */
    private $prenom;

    /**
     * @var string
     *
     * @ORM\Column(name="pwd", type="text")
     * @Assert\NotBlank()
     * @Assert\Length(min=4, minMessage="Le mot de passe doit avoir au moins 4 caractères.")
     * @Assert\Length(max=12, maxMessage="Le mot de passe ne doit pas dépasser 12 caractères.")
     */
    private $pwd;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="date_naissance", type="date")
     * @Assert\Date()
     */
    private $dateNaissance;

    /**
     * @var string
     *
     * @ORM\Column(name="mail", type="text")
     * @Assert\Email(checkMX=true)
     * @Assert\NotBlank()
     */
    private $mail;

    /**
     * @var integer
     *
     * @ORM\Column(name="num_telephone", type="integer")
     */
    private $numTelephone;

    /**
     * @var boolean
     *
     * @ORM\Column(name="sexe", type="boolean")
     */
    private $sexe;

    /**
     * @var boolean
     *
     * @ORM\Column(name="statut", type="boolean")
     */
    private $statut;

    /**
     * @var string
     *
     * @ORM\Column(name="ufr", type="text")
     * @Assert\NotBlank()
     */
    private $ufr;

    private $centreInteret;

    /**
     * @var string
     *
     * @ORM\Column(name="login", type="text", unique=true)
     * @Assert\NotBlank()
     * @Assert\Length(min=4, minMessage="Le login doit avoir au moins 4 caractères")
     * @Assert\Length(max=15, maxMessage="Le login doit avoir au moins 15 caractères")
     */
    private $login;

    private $bdd;

    public function __construct($bdRecup)
    {
      $this->dateNaissance = new \Datetime;
      $this->bdd = $bdRecup;
    }

    public function setUtilisateur()
    {
        $req = $this->bdd->prepare('INSERT INTO utilisateur (nom, prenom, login, pwd, date_naissance, sexe, mail, ufr, statut)
                                    VALUES(:nom,:prenom,:login,:pwd,:date_naissance,:sexe,:mail,:ufr,:statut)');
        $req->execute(array(
            'nom' => $this->getNom(),
            'prenom' => $this->getPrenom(),
            'login' => $this->getLogin(),
            'pwd' => $this->getPwd(),
            'date_naissance' => $this->getDateNaissance()->format('Y-m-d'),
            'sexe' => $this->getSexe(),
            'mail' => $this->getMail(),
            'ufr' => $this->getUfr(),
            'statut' => true )) or die(print_r($req->errorInfo()));
    }

    public function updateUtilisateur($bdd)
    {
        $this->bdd = $bdd;
        $req = $this->bdd->prepare('UPDATE utilisateur 
                                    SET nom = :nvnom, prenom = :nvprenom, pwd = :nvpwd, date_naissance = :nvdate, sexe = :nvsexe, mail = :nvmail,
                                        ufr = :nvufr, num_telephone = :nvnum WHERE login = :login');
        $req->execute(array('nvnom' => $this->getNom(),
                            'nvprenom' => $this->getPrenom(),
                            'nvpwd' => $this->getPwd(),
                            'nvdate' => $this->getDateNaissance()->format('Y-m-d'),
                            'nvsexe' => $this->getSexe(),
                            'nvmail' => $this->getMail(),
                            'nvufr' => $this->getUfr(),
                            'nvnum' => $this->getNumTelephone(),
                            'login' => $this->getLogin() )) or die(print_r($req->errorInfo()));
    }

    public function getUtilisateur($login)
    {
        $req = $this->bdd->prepare('SELECT * FROM utilisateur WHERE login = :login');
        $req->execute(array('login' => $login)) or die(print_r($req->errorInfo()));

        $utilisateur = $req->fetch(); // On instancie la variable qui contiendra la ligne de l'utilisateur concerné

        $req->closeCursor(); // On ferme le cursor

        return $utilisateur;
    }

    //fonction qui sera utiliser pour afficher 5 contacts max avec statut true dans UserBar 
    public function getUsersFriendListS($id_utilisateur)
    {
        $req = $this->bdd->prepare('SELECT u.id_utilisateur, u.nom, u.prenom, u.statut, u.login
                                    FROM utilisateur AS u, liste_amis AS l 
                                    WHERE l.id_utilisateur = :id_utilisateur AND l.id_utilisateur_ami = u.id_utilisateur AND u.statut = TRUE
                                    OR l.id_utilisateur_ami = :id_utilisateur AND l.id_utilisateur = u.id_utilisateur AND u.statut = TRUE
                                    ORDER BY u.nom ASC
                                    LIMIT 10');

        $req->execute(array('id_utilisateur' => $id_utilisateur)) or die(print_r($req->errorInfo()));

        // On instancie la variable qui contiendra la liste des friends du user concerné
        $friendList = array ();
        while ($donnees = $req->fetch())
        {
            array_push($friendList, $donnees);
        }

        $req->closeCursor(); // On ferme le cursor

        return $friendList;
    }

    // fonction qui sera utilisé pour afficher tout les contacts dans UserFriendListLayout
    public function getUsersFriendListL($id_utilisateur)
    {
        $req = $this->bdd->prepare('SELECT u.id_utilisateur, u.nom, u.prenom, u.date_naissance, u.sexe, u.num_telephone, u.mail, u.ufr, u.statut 
                                    FROM utilisateur AS u, liste_amis AS l 
                                    WHERE l.id_utilisateur = :id_utilisateur AND l.id_utilisateur_ami = u.id_utilisateur
                                    OR l.id_utilisateur_ami = :id_utilisateur AND l.id_utilisateur = u.id_utilisateur');

        $req->execute(array('id_utilisateur' => $id_utilisateur)) or die(print_r($req->errorInfo()));

        // On instancie la variable qui contiendra la liste des friends du user concerné
        $friendList = array ();
        while ($donnees = $req->fetch())
        {
            array_push($friendList, $donnees);
        }

        $req->closeCursor(); // On ferme le cursor

        return $friendList;
    }

    public function isFriendWith($id_utilisateur, $id_friend)
    {
        $req = $this->bdd->prepare('SELECT id_utilisateur, id_utilisateur_ami 
                                    FROM liste_amis 
                                    WHERE id_utilisateur = :id_friend AND id_utilisateur_ami = :id_utilisateur
                                    OR id_utilisateur = :id_utilisateur AND id_utilisateur_ami = :id_friend');

        $req->execute(array('id_utilisateur' => $id_utilisateur, 'id_friend' => $id_friend)) or die(print_r($req->errorInfo()));

        $IsFriendWith = array ();
        while ($donnees = $req->fetch())
        {
            array_push($IsFriendWith, $donnees);
        }

        $req->closeCursor(); // On ferme le cursor

        return $IsFriendWith;
    }

    public function addFriend($id_utilisateur, $id_friend)
    {
        $req = $this->bdd->prepare('INSERT INTO liste_amis 
                                    VALUES ((SELECT id_utilisateur 
                                            FROM utilisateur 
                                            WHERE id_utilisateur = :id_utilisateur),
                                            (SELECT id_utilisateur 
                                            FROM utilisateur 
                                            WHERE id_utilisateur = :id_friend))');

        $req->execute(array('id_utilisateur' => $id_utilisateur, 'id_friend' => $id_friend)) or die(print_r($req->errorInfo()));
    }

    public function setCentreInteretUser($id_utilisateur, $interets)
    {
        foreach ($interets as $interet) 
        {
            $req = $this->bdd->prepare('INSERT INTO interet (titre_interet, id_utilisateur) 
                                        VALUES (:interet,
                                                (SELECT id_utilisateur 
                                                FROM utilisateur 
                                                WHERE id_utilisateur = :id_utilisateur))');

            $req->execute(array('id_utilisateur' => $id_utilisateur, 'interet' => $interet)) or die(print_r($req->errorInfo()));
        }
    }

    public function getCentreInteretUser($id_utilisateur)
    {
        $req = $this->bdd->prepare('SELECT titre_interet 
                                    FROM interet
                                    WHERE id_utilisateur = :id_utilisateur');

        $req->execute(array('id_utilisateur' => $id_utilisateur)) or die(print_r($req->errorInfo()));

        // On instancie la variable qui contiendra la liste des centres D'intérêt du user concerné
        $InterestList = array ();
        while ($donnees = $req->fetch())
        {
            array_push($InterestList, $donnees);
        }

        $req->closeCursor(); // On ferme le cursor

        return $InterestList;
    }

    /**
     * Get id
     *
     * @return integer 
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set nom
     *
     * @param string $nom
     * @return Utilisateur
     */
    public function setNom($nom)
    {
        $this->nom = $nom;

        return $this;
    }

    /**
     * Get nom
     *
     * @return string 
     */
    public function getNom()
    {
        return $this->nom;
    }

    /**
     * Set prenom
     *
     * @param string $prenom
     * @return Utilisateur
     */
    public function setPrenom($prenom)
    {
        $this->prenom = $prenom;

        return $this;
    }

    /**
     * Get prenom
     *
     * @return string 
     */
    public function getPrenom()
    {
        return $this->prenom;
    }

    /**
     * Set pwd
     *
     * @param string $pwd
     * @return Utilisateur
     */
    public function setPwd($pwd)
    {
        $this->pwd = $pwd;

        return $this;
    }

    /**
     * Get pwd
     *
     * @return string 
     */
    public function getPwd()
    {
        return $this->pwd;
    }

    /**
     * Get password
     *
     * @return string 
     */
    public function getPassword()
    {
        return $this->pwd;
    }

    /**
     * Set dateNaissance
     *
     * @param \DateTime $dateNaissance
     * @return Utilisateur
     */
    public function setDateNaissance($dateNaissance)
    {
        $this->dateNaissance = $dateNaissance;

        return $this;
    }

    /**
     * Get dateNaissance
     *
     * @return \DateTime 
     */
    public function getDateNaissance()
    {
        return $this->dateNaissance;
    }

    /**
     * Set mail
     *
     * @param string $mail
     * @return Utilisateur
     */
    public function setMail($mail)
    {
        $this->mail = $mail;

        return $this;
    }

    /**
     * Get mail
     *
     * @return string 
     */
    public function getMail()
    {
        return $this->mail;
    }

    /**
     * Set numTelephone
     *
     * @param integer $numTelephone
     * @return Utilisateur
     */
    public function setNumTelephone($numTelephone)
    {
        $this->numTelephone = $numTelephone;

        return $this;
    }

    /**
     * Get numTelephone
     *
     * @return integer 
     */
    public function getNumTelephone()
    {
        return $this->numTelephone;
    }

    /**
     * Set sexe
     *
     * @param boolean $sexe
     * @return Utilisateur
     */
    public function setSexe($sexe)
    {
        $this->sexe = $sexe;

        return $this;
    }

    /**
     * Get sexe
     *
     * @return boolean 
     */
    public function getSexe()
    {
        return $this->sexe;
    }

    /**
     * Set statut
     *
     * @param boolean $statut
     * @return Utilisateur
     */
    public function setStatut($statut)
    {
        $this->statut = $statut;

        return $this;
    }

    /**
     * Get statut
     *
     * @return boolean 
     */
    public function getStatut()
    {
        return $this->statut;
    }

    /**
     * Set ufr
     *
     * @param string $ufr
     * @return Utilisateur
     */
    public function setUfr($ufr)
    {
        $this->ufr = $ufr;

        return $this;
    }

    /**
     * Get ufr
     *
     * @return string 
     */
    public function getUfr()
    {
        return $this->ufr;
    }

    /**
     * Set login
     *
     * @param string $login
     * @return Utilisateur
     */
    public function setLogin($login)
    {
        $this->login = $login;

        return $this;
    }

    /**
     * Get login
     *
     * @return string 
     */
    public function getLogin()
    {
        return $this->login;
    }

    public function getUsername()
    {
        return $this->login;
    }

    public function getSalt()
    {
        return '';
    }

    public function setRoles()
    {
        $roles = array('ROLE_USER');
        return $roles;
    }

    public function getRoles()
    {
        $roles = array('ROLE_USER');
        return $roles;
    }

    public function setCentreInteret($centreInteret)
    {
        $this->centreInteret = $centreInteret;
        return $this;
    }

    public function getCentreInteret()
    {
        return $this->centreInteret;
    }

    public function __sleep()
    {
        return array('id');
    }

    /**
    * serialize the username
    * @return serialize
    */
    public function serialize()
    {
        return serialize($this->id);
    }

    /**
    * unserialize
    * @param $data
    */
    public function unserialize($data)
    {
        $this->login = unserialize($data);
        $this->id = unserialize($data);
    }

    public function eraseCredentials()
    {
    }
}
