<?php

namespace Descartes\UtilisateurBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Descartes\UtilisateurBundle\Entity\Image;
use Descartes\UtilisateurBundle\Form\ImageType;
use Descartes\UtilisateurBundle\Entity\Utilisateur;
use Descartes\UtilisateurBundle\Form\UtilisateurType;
use Descartes\UtilisateurBundle\Form\UtilisateurEditType;
use Symfony\Component\Security\Core\SecurityContext;
use Doctrine\DBAL\Types\Type;


class UtilisateurController extends Controller
{
    public function indexAction()
    {
    	$service_Recupbd = $this->container->get('descartes_recupbd.Recupbd');
    	// Récupération de la liste courtes des amis de l'utilisateur logged
    	$utilisateur = new Utilisateur($service_Recupbd->getBd());
    	$friendListS=$utilisateur->getUsersFriendListS($this->getUser()->getId());

    	$userLogged = $this->getUser();
    	$token = new \Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken(
			  $userLogged, null, 'main', $userLogged->getRoles()); //rectifie pb Authenticated user
    	$this->container->get('security.context')->setToken($token);

        return $this->render('DescartesUtilisateurBundle:Utilisateur:index.html.twig', array('friends' => $friendListS));
    }

    public function inscriptionAction()
    {
    	$service_Recupbd = $this->container->get('descartes_recupbd.Recupbd');
    	$bdd = $service_Recupbd->getBd();
    	$user = new Utilisateur($bdd);
    	$form = $this->createForm(new UtilisateurType, $user); // Appel au formulaire par defaut d'utilisateur

		// On récupère la requête
    	$request = $this->get('request');

	    // On vérifie qu'elle est de type POST
	    if ($request->getMethod() == 'POST')
	    {
	      // On fait le lien Requête <-> Formulaire
	      // À partir de maintenant, la variable $utilisateur contient les valeurs entrées dans le formulaire par le visiteur
	      $form->bind($request);

	      // On vérifie que les valeurs entrées sont correctes
	      	if ($form->isValid())
		    {
		        // On l'enregistre notre objet $utilisateur dans la base de données
		    	$user->setUtilisateur();

		        // On redirige vers la page accueil
		        return $this->redirect($this->generateUrl('descartes_evenement_homepage'));
		    }
	    }

		// On passe la méthode createView() du formulaire à la vue afin qu'elle puisse afficher le formulaire toute seule
		return $this->render('DescartesUtilisateurBundle:Utilisateur:inscription.html.twig', array(
		  'form' => $form->createView(),));
    }

    public function profilAction($login)
    {
    	// On recupère l'utilisateur en fonction du login
    	$service_Recupbd = $this->container->get('descartes_recupbd.Recupbd');
    	$utilisateur = new Utilisateur($service_Recupbd->getBd());
    	$user=$utilisateur->getUtilisateur($login);

    	$ami=$utilisateur->isFriendWith($this->getUser()->getId(), $user['id_utilisateur']);

    	$interestList = $utilisateur->getCentreInteretUser($user['id_utilisateur']);
    	
    	return $this->render('DescartesUtilisateurBundle:Utilisateur:profil.html.twig', 
    						array('user' => $user, 'ami' => $ami, 'interestList' => $interestList));
    }

    public function loginAction()
    {
    	
    	// Si le visiteur est déjà identifié, on le redirige vers l'accueil
	    if ($this->get('security.context')->isGranted('IS_AUTHENTICATED_REMEMBERED')) {
	    	
	      return $this->redirect($this->generateUrl('descartes_evenement_homepage'));
	    }

	    $request = $this->getRequest();
	    $session = $request->getSession();

	    // On vérifie s'il y a des erreurs d'une précédente soumission du formulaire
	    if ($request->attributes->has(SecurityContext::AUTHENTICATION_ERROR)) {
	      $error = $request->attributes->get(SecurityContext::AUTHENTICATION_ERROR);
	    } else {
	      $error = $session->get(SecurityContext::AUTHENTICATION_ERROR);
	      $session->remove(SecurityContext::AUTHENTICATION_ERROR);
	    }

	    return $this->render('DescartesUtilisateurBundle:Utilisateur:login.html.twig', array(
	      // Valeur du précédent nom d'utilisateur entré par l'internaute
	      'last_username' => $session->get(SecurityContext::LAST_USERNAME),
	      'error'         => $error,));
    }

    public function settingAction()
    {
    	//Si l'utilsateur n'est pas authentifié, on redirige vers l'accueil
	    if($this->getUser() == null)
	    {
	    	return $this->redirect($this->generateUrl('descartes_evenement_homepage'));
	    }

    	$service_Recupbd = $this->container->get('descartes_recupbd.Recupbd');
    	$login = $this->getUser()->getLogin();

    	$user = $this->getUser();
    	$formProfil = $this->createForm(new UtilisateurEditType, $user); // Appel au formulaire par defaut d'utilisateur

    	$image = new Image();
    	$formImage = $this->createForm(new ImageType, $image); // Appel au formulaire par defaut d'image

    	// On récupère la requête
    	$request = $this->get('request');

	    // On vérifie qu'elle est de type POST
	    if ($request->getMethod() == 'POST')
	    {
	      // On fait le lien Requête <-> Formulaire
	      // À partir de maintenant, la variable $utilisateur et $image contiennent les valeurs entrées dans les formulaires par le visiteur
	      $formProfil->bind($request);
	      $formImage->bind($request);

	      // On vérifie que les valeurs entrées sont correctes
	      // (Nous verrons la validation des objets en détail dans le prochain chapitre)
	      	if ($formProfil->isValid())
		    {
		        // On l'enregistre notre objet $utilisateur dans la base de données
		    	$user->updateUtilisateur($service_Recupbd->getBd());

		        // On redirige vers la page profil
		        return $this->redirect($this->generateUrl('descartes_utilisateur_profil', array('login' => $this->getUser()->getLogin())));
		    }
		    else if($formImage->isValid())
		    {
		    	// On execute la fonction upload qui enregistre l'image dans les dossiers serveur.
		    	$image->upload($this->getUser()->getId());	

		    	// On redirige vers la page profil
		        return $this->redirect($this->generateUrl('descartes_utilisateur_profil', array('login' => $this->getUser()->getLogin())));
		    }
	    }

	    return $this->render('DescartesUtilisateurBundle:Utilisateur:setting.html.twig', 
    							array('formProfil' => $formProfil->createView(), 'formImage' => $formImage->createView(), 'login' => $login));
    }
}
