<?php

namespace Descartes\UtilisateurBundle\Form;

use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class UtilisateurEditType extends UtilisateurType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        // On fait appel à la méthode buildForm du parent, qui va ajouter tous les champs à $builder
        parent::buildForm($builder, $options);

        // On supprime le champ qu'on ne veut pas dans le formulaire de modification
        $builder->remove('login');

        // On ajoute les champs qu'on veut voir apparaitre dans le formulaire de modification
        $builder->add('numTelephone',   'text', array('required' => false));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'descartes_utilisateurbundle_utilisateuredit';
    }
}
